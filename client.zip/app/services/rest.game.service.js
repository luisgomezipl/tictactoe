"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const http_1 = require("@angular/http");
const router_1 = require("@angular/router");
const security_service_1 = require("./security.service");
const global_service_1 = require("./global.service");
const rest_base_1 = require("./rest.base");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/map");
let RestGameService = class RestGameService extends rest_base_1.RestBase {
    constructor(http, router, userSecurity, global) {
        super(http, router, userSecurity, global);
        this.http = http;
        this.router = router;
        this.userSecurity = userSecurity;
        this.global = global;
        this.restUrl = 'http://localhost:8080/v1/'; // URL to web API
    }
    preregister(name, email, username) {
        let userInfo = {
            'name': name,
            'email': email,
            'username': username,
        };
        return this.http
            .post(this.restUrl + 'preregister', userInfo)
            .map(this.extractData)
            .catch(this.handleError.bind(this));
    }
    topTen() {
        return this.http
            .get(this.restUrl + 'users/topten')
            .map(this.extractData)
            .catch(this.handleError.bind(this));
    }
    lobby() {
        return this.http
            .get(this.restUrl + 'games/lobby', this.authorizationOptions())
            .map(this.extractData)
            .catch(this.handleError.bind(this));
    }
    history(historyType) {
        return this.http
            .get(this.restUrl + 'games/history/' + historyType, this.authorizationOptions())
            .map(this.extractData)
            .catch(this.handleError.bind(this));
    }
    createGame() {
        return this.http
            .post(this.restUrl + 'games', {}, this.authorizationOptions())
            .map(this.extractData)
            .catch(this.handleError.bind(this));
    }
    joinGame(gameId) {
        return this.http
            .post(this.restUrl + 'games/join', { id: gameId }, this.authorizationOptions())
            .map(this.extractData)
            .catch(this.handleError.bind(this));
    }
    removeGame(gameId) {
        return this.http
            .post(this.restUrl + 'games/remove', { id: gameId }, this.authorizationOptions())
            .map(this.extractData)
            .catch(this.handleError.bind(this));
    }
};
RestGameService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http,
        router_1.Router,
        security_service_1.UserSecurityService,
        global_service_1.Global])
], RestGameService);
exports.RestGameService = RestGameService;
//# sourceMappingURL=rest.game.service.js.map