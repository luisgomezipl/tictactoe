"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const http_1 = require("@angular/http");
const router_1 = require("@angular/router");
const security_service_1 = require("./security.service");
const global_service_1 = require("./global.service");
const rest_base_1 = require("./rest.base");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/map");
let RestAuthService = class RestAuthService extends rest_base_1.RestBase {
    constructor(http, router, userSecurity, global) {
        super(http, router, userSecurity, global);
        this.http = http;
        this.router = router;
        this.userSecurity = userSecurity;
        this.global = global;
        this.restUrl = 'http://localhost/api/'; // URL to web API
    }
    checkUniqueUsername(username) {
        return this.http
            .post(this.restUrl + 'uniqueusername.php', JSON.stringify({ 'username': username }))
            .map(this.extractData)
            .catch(this.handleError.bind(this, [403]));
    }
    checkUniqueEmail(email) {
        return this.http
            .post(this.restUrl + 'uniqueemail.php', JSON.stringify({ 'email': email }))
            .map(this.extractData)
            .catch(this.handleError.bind(this, [403]));
    }
    authenticate(username, password) {
        let credentials = {
            'username': username,
            'password': password
        };
        return this.http
            .post(this.restUrl + 'authenticate.php', JSON.stringify(credentials))
            .map(this.extractData)
            .catch(this.handleError.bind(this, [401]));
    }
    registerUser(userInfoFromPreRegister, password) {
        let userInfo = {
            'name': userInfoFromPreRegister.name,
            'email': userInfoFromPreRegister.email,
            'username': userInfoFromPreRegister.username,
            'password': password,
            'id': userInfoFromPreRegister.userID
        };
        return this.http
            .post(this.restUrl + 'register.php', JSON.stringify(userInfo))
            .map(this.extractData)
            .catch(this.handleError.bind(this));
    }
    changePassword(oldpassword, newpassword) {
        let passInfo = {
            'oldpassword': oldpassword,
            'newpassword': newpassword,
        };
        return this.http
            .put(this.restUrl + 'changepassword.php', JSON.stringify(passInfo), this.authorizationOptions())
            .map(this.extractData)
            .catch(this.handleError.bind(this, [401]));
    }
};
RestAuthService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http,
        router_1.Router,
        security_service_1.UserSecurityService,
        global_service_1.Global])
], RestAuthService);
exports.RestAuthService = RestAuthService;
//# sourceMappingURL=rest.auth.service.js.map