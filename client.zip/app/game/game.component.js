"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const games_component_1 = require("./games.component");
const security_service_1 = require("../services/security.service");
var GameStatus;
(function (GameStatus) {
    GameStatus[GameStatus["turnPlayer1"] = 1] = "turnPlayer1";
    GameStatus[GameStatus["turnPlayer2"] = 2] = "turnPlayer2";
    GameStatus[GameStatus["endedTie"] = 10] = "endedTie";
    GameStatus[GameStatus["endedWonPlayer1"] = 11] = "endedWonPlayer1";
    GameStatus[GameStatus["endedWonPlayer2"] = 12] = "endedWonPlayer2";
    GameStatus[GameStatus["canceledByPlayer1"] = 21] = "canceledByPlayer1";
    GameStatus[GameStatus["canceledByPlayer2"] = 22] = "canceledByPlayer2";
    GameStatus[GameStatus["timeout"] = 30] = "timeout";
})(GameStatus || (GameStatus = {}));
let GameComponent = class GameComponent {
    constructor(userSecurity) {
        this.userSecurity = userSecurity;
        this.onClickPeca = new core_1.EventEmitter(false);
        this.onClickClose = new core_1.EventEmitter(false);
        this.pecaImageURL = (peca) => {
            let imgSrc = String(peca);
            if (peca > 0) {
                if (peca == this.currentPlayerNumber()) {
                    imgSrc += '-b';
                }
                else {
                    imgSrc += '-c';
                }
            }
            return 'img/' + imgSrc + '.png';
        };
        this.currentPlayerNumber = () => {
            if (this.userSecurity.getUserID() == this.gameInfo.game.player1) {
                return 1;
            }
            if (this.userSecurity.getUserID() == this.gameInfo.game.player2) {
                return 2;
            }
            return 0;
        };
        this.nameOfPlayer = (numberOfPlayer) => {
            if (this.currentPlayerNumber() == numberOfPlayer) {
                if (numberOfPlayer == 1) {
                    return this.gameInfo.game.player1Name + " (You)";
                }
                else {
                    return this.gameInfo.game.player2Name + " (You)";
                }
            }
            else {
                if (numberOfPlayer == 1) {
                    return this.gameInfo.game.player1Name;
                }
                else {
                    return this.gameInfo.game.player2Name;
                }
            }
        };
        this.clickPeca = (position) => {
            this.onClickPeca.emit({ 'gameId': this.gameInfo.gameId, 'position': position });
        };
        this.clickClose = () => {
            if (this.gameEnded()) {
                this.onClickClose.emit({ 'gameId': this.gameInfo.gameId, 'operation': 'hide' });
            }
            else {
                this.onClickClose.emit({ 'gameId': this.gameInfo.gameId, 'operation': 'quit' });
            }
        };
        this.gameEnded = () => {
            return this.gameInfo.gameControlStatus == games_component_1.GameControlStatus.ended;
        };
        this.submitText = () => {
            if (this.gameEnded()) {
                return "Hide game";
            }
            else {
                return "Quit game";
            }
        };
        this.submitClass = () => {
            if (this.gameEnded()) {
                return "btn-info";
            }
            else {
                return "btn-danger";
            }
        };
        this.alertClass = () => {
            switch (this.gameInfo.game.gameStatus) {
                case GameStatus.turnPlayer1:
                    if (this.currentPlayerNumber() == 1) {
                        return "alert-info";
                    }
                    else {
                        return "alert-warning";
                    }
                case GameStatus.turnPlayer2:
                    if (this.currentPlayerNumber() == 2) {
                        return "alert-info";
                    }
                    else {
                        return "alert-warning";
                    }
                case GameStatus.endedTie:
                    return "alert-warning";
                case GameStatus.endedWonPlayer1:
                    if (this.currentPlayerNumber() == 1) {
                        return "alert-success";
                    }
                    else {
                        return "alert-danger";
                    }
                case GameStatus.endedWonPlayer2:
                    if (this.currentPlayerNumber() == 2) {
                        return "alert-success";
                    }
                    else {
                        return "alert-danger";
                    }
                case GameStatus.canceledByPlayer1:
                    if (this.currentPlayerNumber() == 1) {
                        return "alert-danger";
                    }
                    else {
                        return "alert-warning";
                    }
                case GameStatus.canceledByPlayer2:
                    if (this.currentPlayerNumber() == 2) {
                        return "alert-danger";
                    }
                    else {
                        return "alert-warning";
                    }
                case GameStatus.timeout:
                    return "alert-danger";
            }
        };
        this.alertText = () => {
            switch (this.gameInfo.game.gameStatus) {
                case GameStatus.turnPlayer1:
                    if (this.currentPlayerNumber() == 1) {
                        return "It's your Turn.";
                    }
                    else {
                        return "It's your opponent's turn.";
                    }
                case GameStatus.turnPlayer2:
                    if (this.currentPlayerNumber() == 2) {
                        return "It's your Turn.";
                    }
                    else {
                        return "It's your opponent's turn.";
                    }
                case GameStatus.endedTie:
                    return "Game has ended. There was a tie!";
                case GameStatus.endedWonPlayer1:
                    if (this.currentPlayerNumber() == 1) {
                        return "Game has ended. You Win!";
                    }
                    else {
                        return "Game has ended. You Lost!";
                    }
                case GameStatus.endedWonPlayer2:
                    if (this.currentPlayerNumber() == 2) {
                        return "Game has ended. You Win!";
                    }
                    else {
                        return "Game has ended. You Lost!";
                    }
                case GameStatus.canceledByPlayer1:
                    if (this.currentPlayerNumber() == 1) {
                        return "Game was canceled by you!";
                    }
                    else {
                        return "Game was canceled by your opponent!";
                    }
                case GameStatus.canceledByPlayer2:
                    if (this.currentPlayerNumber() == 2) {
                        return "Game was canceled by you!";
                    }
                    else {
                        return "Game was canceled by your opponent!";
                    }
                case GameStatus.timeout:
                    return "Game was terminated due to a timeout!";
            }
        };
    }
};
__decorate([
    core_1.Input(),
    __metadata("design:type", games_component_1.GameInfo)
], GameComponent.prototype, "gameInfo", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], GameComponent.prototype, "onClickPeca", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], GameComponent.prototype, "onClickClose", void 0);
GameComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'game',
        templateUrl: 'game.component.html'
    }),
    __metadata("design:paramtypes", [security_service_1.UserSecurityService])
], GameComponent);
exports.GameComponent = GameComponent;
//# sourceMappingURL=game.component.js.map