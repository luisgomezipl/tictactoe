"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const rest_game_service_1 = require("../services/rest.game.service");
const security_service_1 = require("../services/security.service");
const websocket_service_1 = require("../services/websocket.service");
const router_1 = require("@angular/router");
let LobbyComponent = class LobbyComponent {
    constructor(router, restGameService, userSecurity, websocketService) {
        this.router = router;
        this.restGameService = restGameService;
        this.userSecurity = userSecurity;
        this.websocketService = websocketService;
        this.games = [];
    }
    ngOnInit() {
        this.errorMessage = "";
        this.fillGames();
        this.subscriptions = [];
        this.subscriptions.push(this.websocketService.getLobbyChanged().subscribe((obj) => this.lobbyChanged(obj)));
    }
    ngOnDestroy() {
        this.subscriptions.forEach((subscription) => {
            subscription.unsubscribe();
        });
        this.subscriptions = [];
    }
    // WebServer notifications from server
    lobbyChanged(obj) {
        this.fillGames();
    }
    fillGames() {
        this.restGameService.lobby()
            .subscribe(games => this.games = games, error => this.errorMessage = error);
    }
    createGame() {
        this.errorMessage = "";
        let component = this;
        this.restGameService.createGame()
            .subscribe(createdGame => {
            component.fillGames();
        }, error => {
            component.errorMessage = "There was an error creating the game";
        });
    }
    createdByMe(createdBy) {
        return createdBy == this.userSecurity.getUserID();
    }
    joinGame(gameId) {
        this.errorMessage = "";
        let component = this;
        this.restGameService.joinGame(gameId)
            .subscribe(updatedGame => {
            this.websocketService.enterGame(gameId);
            this.router.navigate(['/games']);
            //component.fillGames();
        }, error => {
            component.errorMessage = "There was an error joining the game";
        });
    }
    removeGame(gameId) {
        this.errorMessage = "";
        let component = this;
        this.restGameService.removeGame(gameId)
            .subscribe(updatedGame => {
            component.fillGames();
        }, error => {
            component.errorMessage = "There was an error removing the game";
        });
    }
};
LobbyComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'lobby',
        templateUrl: 'lobby.component.html'
    }),
    __metadata("design:paramtypes", [router_1.Router,
        rest_game_service_1.RestGameService,
        security_service_1.UserSecurityService,
        websocket_service_1.WebSocketService])
], LobbyComponent);
exports.LobbyComponent = LobbyComponent;
//# sourceMappingURL=lobby.component.js.map