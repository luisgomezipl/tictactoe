"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const platform_browser_1 = require("@angular/platform-browser");
const http_1 = require("@angular/http");
const forms_1 = require("@angular/forms");
const app_component_1 = require("./app.component");
const home_component_1 = require("./general/home.component");
const error_component_1 = require("./general/error.component");
const login_component_1 = require("./auth/login.component");
const register_component_1 = require("./auth/register.component");
const changepassword_component_1 = require("./auth/changepassword.component");
const lobby_component_1 = require("./lobby/lobby.component");
const games_data_component_1 = require("./data-view/games.data.component");
const top_component_1 = require("./data-view/top.component");
const games_component_1 = require("./game/games.component");
const game_component_1 = require("./game/game.component");
const app_routing_module_1 = require("./routes/app-routing.module");
const rest_game_service_1 = require("./services/rest.game.service");
const rest_auth_service_1 = require("./services/rest.auth.service");
const security_service_1 = require("./services/security.service");
const websocket_service_1 = require("./services/websocket.service");
const auth_guard_service_1 = require("./services/auth.guard.service");
const global_service_1 = require("./services/global.service");
let AppModule = class AppModule {
};
AppModule = __decorate([
    core_1.NgModule({
        imports: [
            platform_browser_1.BrowserModule,
            app_routing_module_1.AppRoutingModule,
            http_1.HttpModule,
            forms_1.FormsModule,
            forms_1.ReactiveFormsModule
        ],
        declarations: [
            app_component_1.AppComponent,
            home_component_1.HomeComponent,
            error_component_1.ErrorComponent,
            login_component_1.LoginComponent,
            register_component_1.RegisterComponent,
            changepassword_component_1.ChangePasswordComponent,
            lobby_component_1.LobbyComponent,
            games_data_component_1.GamesDataComponent,
            top_component_1.TopComponent,
            games_component_1.GamesComponent,
            game_component_1.GameComponent
        ],
        providers: [
            rest_auth_service_1.RestAuthService,
            rest_game_service_1.RestGameService,
            security_service_1.UserSecurityService,
            auth_guard_service_1.AuthGuard,
            global_service_1.Global,
            websocket_service_1.WebSocketService
        ],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map