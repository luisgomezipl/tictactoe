"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const websocket_service_1 = require("../services/websocket.service");
const security_service_1 = require("../services/security.service");
var GameControlStatus;
(function (GameControlStatus) {
    GameControlStatus[GameControlStatus["playing"] = 0] = "playing";
    GameControlStatus[GameControlStatus["ended"] = 1] = "ended";
})(GameControlStatus = exports.GameControlStatus || (exports.GameControlStatus = {}));
class GameInfo {
    get gameControlStatus() {
        if (this.game.gameStatus < 10) {
            return GameControlStatus.playing;
        }
        else {
            return GameControlStatus.ended;
        }
    }
}
exports.GameInfo = GameInfo;
let GamesComponent = class GamesComponent {
    constructor(userSecurity, websocketService) {
        this.userSecurity = userSecurity;
        this.websocketService = websocketService;
    }
    ngOnInit() {
        this.subscriptions = [];
        this.subscriptions.push(this.websocketService.getMyListOfGames().subscribe((myGames) => this.getListOfMyGames(myGames)));
        this.subscriptions.push(this.websocketService.getRefreshGame().subscribe((game) => this.refreshGame(game)));
        this.subscriptions.push(this.websocketService.getGameInvalidPlay().subscribe((obj) => this.invalidPlay(obj)));
        this.subscriptions.push(this.websocketService.getGamesListChanged().subscribe((obj) => this.gamesListChanged(obj)));
        this.refreshActiveGames();
    }
    ngOnDestroy() {
        this.subscriptions.forEach((subscription) => {
            subscription.unsubscribe();
        });
        this.subscriptions = [];
    }
    getGameInfoById(gameId) {
        let resultGame = null;
        this.games.forEach(game => {
            if (game.gameId == gameId) {
                resultGame = game;
                return;
            }
        });
        return resultGame;
    }
    deleteInfoGameById(gameId) {
        let toDelete = this.getGameInfoById(gameId);
        if (toDelete) {
            this.games.indexOf(toDelete);
            this.games.splice(this.games.indexOf(toDelete), 1);
        }
    }
    getGameById(gameId) {
        return this.getGameInfoById(gameId).game;
    }
    getGameInfo(g) {
        return this.getGameInfoById(g.gameId);
    }
    getGame(g) {
        return this.getGameInfo(g).game;
    }
    // getGame and replace its content
    getSetGameInfo(g) {
        let resultGame = null;
        this.games.forEach(game => {
            if (game.gameId == g.gameId) {
                game.game = g;
                resultGame = game;
                return;
            }
        });
        return resultGame;
    }
    getSetGame(g) {
        return this.getSetGameInfo(g).game;
    }
    buildGames(games) {
        let component = this;
        this.games = [];
        games.forEach(game => {
            let gameInfo = new GameInfo();
            gameInfo.gameId = game.gameId;
            gameInfo.game = game;
            component.games.push(gameInfo);
        });
    }
    // ---------------------------------------------------------------------------------
    // Server Message Handlers:
    // ---------------------------------------------------------------------------------    
    gamesListChanged(obj) {
        if (this.userSecurity.isLogged()) {
            if ((obj.player1 == this.userSecurity.getUserID()) ||
                (obj.player2 == this.userSecurity.getUserID())) {
                this.refreshActiveGames();
            }
        }
    }
    getListOfMyGames(myGames) {
        this.buildGames(myGames);
    }
    ;
    refreshGame(game) {
        var d = new Date();
        var n = d.getTime();
        window.console.log("TimeMarkReceive: " + n);
        let g = this.getSetGameInfo(game);
    }
    invalidPlay(obj) {
        let g = this.getSetGameInfo(obj.game);
    }
    // ---------------------------------------------------------------------------------
    // Send Messages to Server
    // ---------------------------------------------------------------------------------    
    identifyMyself() {
        this.websocketService.identifyMyself();
    }
    refreshActiveGames() {
        this.identifyMyself();
        this.websocketService.myActiveGames();
    }
    quitGame(gameId) {
        this.websocketService.quitGame(gameId);
    }
    clickPeca(eventObj) {
        var d = new Date();
        var n = d.getTime();
        window.console.log("TimeMarkSend: " + n);
        // Only sends message to the server if game has not ended
        if (this.getGameById(eventObj.gameId).gameStatus < 5) {
            this.websocketService.playGame(eventObj.gameId, eventObj.position);
        }
    }
    clickClose(eventObj) {
        if (eventObj.operation == 'quit') {
            this.websocketService.quitGame(eventObj.gameId);
        }
        else {
            if (eventObj.operation == 'hide') {
                this.deleteInfoGameById(eventObj.gameId);
            }
        }
    }
};
GamesComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'games',
        templateUrl: 'games.component.html'
    }),
    __metadata("design:paramtypes", [security_service_1.UserSecurityService,
        websocket_service_1.WebSocketService])
], GamesComponent);
exports.GamesComponent = GamesComponent;
//# sourceMappingURL=games.component.js.map