"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const security_service_1 = require("./security.service");
const Observable_1 = require("rxjs/Observable");
const io = require("socket.io-client");
class SocketError extends Error {
    constructor(m) {
        super(m);
    }
}
let WebSocketService = class WebSocketService {
    constructor(userSecurity) {
        this.userSecurity = userSecurity;
        if (!this.socket) {
            this.socket = io('http://tictactoe-fullstack.ddns.net:8080'); // URL to webSockets
        }
    }
    identifyMyself() {
        if (this.userSecurity.isLogged()) {
            this.socket.emit('identifyMyself', { 'token': this.userSecurity.token });
        }
        else {
            throw new SocketError('User is not logged - it cannot be identified');
        }
    }
    myActiveGames() {
        this.socket.emit('myActiveGames', { 'notrelevant': 'nothing relevant' });
    }
    enterGame(gameId) {
        this.socket.emit('enterGame', { 'gameId': gameId });
    }
    quitGame(gameId) {
        this.socket.emit('quitGame', { 'gameId': gameId });
    }
    leaveGame(gameId) {
        this.socket.emit('leaveGame', { 'gameId': gameId });
    }
    leaveAllGames() {
        this.socket.emit('leaveAllGames', { 'notrelevant': 'nothing relevant' });
    }
    playGame(gameId, position) {
        this.socket.emit('play', { 'gameId': gameId, 'position': position });
    }
    // Messages from the server
    getMyListOfGames() {
        return this.listenOnChannel('myListOfGames');
    }
    getRefreshGame() {
        return this.listenOnChannel('refreshGame');
    }
    getGameEnded() {
        return this.listenOnChannel('gameEnded');
    }
    getGameInvalidPlay() {
        return this.listenOnChannel('gameInvalidPlay');
    }
    getLobbyChanged() {
        return this.listenOnChannel('lobbyChanged');
    }
    getGamesListChanged() {
        return this.listenOnChannel('gamesPlayingChanged');
    }
    getLobbyJoinGame() {
        return this.listenOnChannel('lobby_joinGame');
    }
    listenOnChannel(channel) {
        return new Observable_1.Observable((observer) => {
            this.socket.on(channel, (data) => {
                observer.next(data);
            });
            return () => {
                this.socket.removeEventListener(channel);
                //this.socket.disconnect();
                // NOTA: MUITO IMPORTANTE
                // Se usar o sicket disconnect, quando se faz unsubscribe, o socket é fechada!!!!
                // Em vez disso remove-se apenas os listeners para esse socket, mantendo o socket aberto
            };
        });
    }
};
WebSocketService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [security_service_1.UserSecurityService])
], WebSocketService);
exports.WebSocketService = WebSocketService;
//# sourceMappingURL=websocket.service.js.map