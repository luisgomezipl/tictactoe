"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const router_1 = require("@angular/router");
const rest_game_service_1 = require("../services/rest.game.service");
const security_service_1 = require("../services/security.service");
let GamesDataComponent = class GamesDataComponent {
    constructor(restGameService, userSecurity, route) {
        this.restGameService = restGameService;
        this.userSecurity = userSecurity;
        this.route = route;
        this.games = [];
    }
    ngOnInit() {
        this.historytype = "";
        this.sub = this.route.params.subscribe(params => {
            this.historytype = params['t'];
            this.fillGames();
        });
    }
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    fillGames() {
        if ((this.historytype == 'mg') || (this.historytype == 'mv') || (this.historytype == 'md') || (this.historytype == 'g')) {
            this.restGameService.history(this.historytype)
                .subscribe(games => this.games = games, error => this.errorMessage = error);
        }
        else {
            this.games = [];
        }
    }
    errorMessageExists() {
        return this.errorMessage != "";
    }
    historyTypeDescription() {
        switch (this.historytype) {
            case 'g':
                return 'All games (last 50)';
            case 'mg':
                return 'My games  (last 50)';
            case 'mv':
                return 'My victories (last 50)';
            case 'md':
                return 'My defeats or ties (last 50)';
            default:
                return '';
        }
    }
    getDuration(terminatedTime, startedTime) {
        let eventStartTime = new Date(startedTime);
        let eventEndTime = new Date(terminatedTime);
        // Returns the number of seconds
        return (eventEndTime.getTime() - eventStartTime.getTime()) / 1000;
    }
    winnerClass(game, playerNumber) {
        /*        if ((this.historytype == 'mv') || (this.historytype == 'md')) {
                    return false;
                }
        */
        if (game.winner == undefined) {
            return false;
        }
        if ((playerNumber == 1) && (game.player1._id == game.winner._id)) {
            return true;
        }
        if ((playerNumber == 2) && (game.player2._id == game.winner._id)) {
            return true;
        }
        return false;
    }
};
GamesDataComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'gamesdata',
        templateUrl: 'games.data.component.html'
    }),
    __metadata("design:paramtypes", [rest_game_service_1.RestGameService,
        security_service_1.UserSecurityService,
        router_1.ActivatedRoute])
], GamesDataComponent);
exports.GamesDataComponent = GamesDataComponent;
//# sourceMappingURL=games.data.component.js.map