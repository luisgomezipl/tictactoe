"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const router_1 = require("@angular/router");
const home_component_1 = require("../general/home.component");
const error_component_1 = require("../general/error.component");
const login_component_1 = require("../auth/login.component");
const register_component_1 = require("../auth/register.component");
const changepassword_component_1 = require("../auth/changepassword.component");
const lobby_component_1 = require("../lobby/lobby.component");
const games_data_component_1 = require("../data-view/games.data.component");
const top_component_1 = require("../data-view/top.component");
const games_component_1 = require("../game/games.component");
const auth_guard_service_1 = require("../services/auth.guard.service");
const routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'home', component: home_component_1.HomeComponent },
    { path: 'error', component: error_component_1.ErrorComponent },
    { path: 'login', component: login_component_1.LoginComponent },
    { path: 'register', component: register_component_1.RegisterComponent },
    { path: 'gamesdata/:t', component: games_data_component_1.GamesDataComponent, canActivate: [auth_guard_service_1.AuthGuard] },
    { path: 'top', component: top_component_1.TopComponent },
    { path: 'lobby', component: lobby_component_1.LobbyComponent, canActivate: [auth_guard_service_1.AuthGuard] },
    { path: 'games', component: games_component_1.GamesComponent, canActivate: [auth_guard_service_1.AuthGuard] },
    { path: 'changepassword', component: changepassword_component_1.ChangePasswordComponent, canActivate: [auth_guard_service_1.AuthGuard] },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = __decorate([
    core_1.NgModule({
        imports: [router_1.RouterModule.forRoot(routes)],
        exports: [router_1.RouterModule]
    })
], AppRoutingModule);
exports.AppRoutingModule = AppRoutingModule;
//# sourceMappingURL=app-routing.module.js.map