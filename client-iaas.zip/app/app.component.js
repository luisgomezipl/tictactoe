"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const router_1 = require("@angular/router");
const security_service_1 = require("./services/security.service");
const websocket_service_1 = require("./services/websocket.service");
let AppComponent = class AppComponent {
    constructor(router, userSecurity, websocketService) {
        this.router = router;
        this.userSecurity = userSecurity;
        this.websocketService = websocketService;
        this.timeoutId = null;
        this.appName = 'TicTacToe';
        this._lastActiveGameId = '';
        this.lastActiveGameNumber = -1;
    }
    get lastActiveGameId() {
        return this._lastActiveGameId;
    }
    set lastActiveGameId(newId) {
        if (this.timeoutId != null) {
            clearTimeout(this.timeoutId);
            this.timeoutId = null;
        }
        let app = this;
        this._lastActiveGameId = newId;
        if (this._lastActiveGameId != "") {
            app.timeoutId = setTimeout(() => {
                app.lastActiveGameId = "";
                clearTimeout(app.timeoutId);
                app.timeoutId = null;
            }, 30000);
        }
    }
    ngOnInit() {
        this.subscriptions = [];
        this.subscriptions.push(this.websocketService.getGameEnded().subscribe((gameId) => this.gameEnded(gameId)));
        this.subscriptions.push(this.websocketService.getLobbyJoinGame().subscribe((obj) => this.lobbyJoinGame(obj)));
    }
    ngOnDestroy() {
        this.websocketService.leaveAllGames();
        this.subscriptions.forEach((subscription) => {
            subscription.unsubscribe();
        });
        this.subscriptions = [];
    }
    lobbyJoinGame(obj) {
        if (this.isLogged()) {
            if (obj.player1 == this.userSecurity.getUserID()) {
                this.websocketService.enterGame(obj.gameId);
                if (this.router.url != '/games') {
                    this.lastActiveGameId = obj.gameId;
                    this.lastActiveGameNumber = obj.gameNumber;
                }
            }
        }
    }
    gameEnded(gameId) {
        this.websocketService.leaveGame(gameId);
    }
    isActiveLink(link) {
        return this.router.isActive(link, true);
    }
    isLogged() {
        return this.userSecurity.isLogged();
    }
    username() {
        return this.userSecurity.getUserName();
    }
    logout() {
        this.lastActiveGameId = "";
        this.lastActiveGameNumber = -1;
        this.userSecurity.logoutUser();
        this.router.navigate(['/']);
    }
    showAlert() {
        return this.lastActiveGameId != '';
    }
    gotoGame(gameId) {
        this.lastActiveGameId = "";
        this.lastActiveGameNumber = -1;
        this.router.navigate(['/games']);
    }
};
AppComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'my-app',
        templateUrl: 'app.component.html'
    }),
    __metadata("design:paramtypes", [router_1.Router,
        security_service_1.UserSecurityService,
        websocket_service_1.WebSocketService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map