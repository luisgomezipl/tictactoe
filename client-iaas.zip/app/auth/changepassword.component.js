"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const router_1 = require("@angular/router");
const forms_1 = require("@angular/forms");
const rest_auth_service_1 = require("../services/rest.auth.service");
const security_service_1 = require("../services/security.service");
let ChangePasswordComponent = class ChangePasswordComponent {
    constructor(fb, restAuthService, userSecurity, router) {
        this.fb = fb;
        this.restAuthService = restAuthService;
        this.userSecurity = userSecurity;
        this.router = router;
        this.matchingPasswords = (passwordKey, confirmPasswordKey) => {
            return (group) => {
                let password = group.controls[passwordKey];
                let confirmPassword = group.controls[confirmPasswordKey];
                if (password.value !== confirmPassword.value) {
                    return {
                        mismatchedPasswords: true
                    };
                }
            };
        };
    }
    ngOnInit() {
        this.complexForm = this.fb.group({
            'oldpassword': [null, forms_1.Validators.required],
            'newpassword1': [null, forms_1.Validators.required],
            'newpassword2': [null, forms_1.Validators.required]
        }, { validator: this.matchingPasswords('newpassword1', 'newpassword2') });
        this.resetData();
    }
    resetData() {
        this.msgValidation = "";
        this.complexForm.reset();
    }
    submitForm(form, event) {
        for (let i in this.complexForm.controls) {
            this.complexForm.controls[i].markAsDirty();
        }
        if (this.complexForm.invalid) {
            event.preventDefault();
        }
        else {
            this.changePassword(form);
        }
    }
    changePassword(form) {
        this.restAuthService.changePassword(form.oldpassword, form.newpassword1)
            .subscribe(updatedUser => {
            this.router.navigateByUrl('/home');
        }, error => {
            this.msgValidation = "Password was not changed! Probably, old password is incorrect.";
        });
    }
};
ChangePasswordComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'changepassword',
        templateUrl: 'changepassword.component.html'
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder,
        rest_auth_service_1.RestAuthService,
        security_service_1.UserSecurityService,
        router_1.Router])
], ChangePasswordComponent);
exports.ChangePasswordComponent = ChangePasswordComponent;
//# sourceMappingURL=changepassword.component.js.map