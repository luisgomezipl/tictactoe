"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const router_1 = require("@angular/router");
const forms_1 = require("@angular/forms");
const rest_auth_service_1 = require("../services/rest.auth.service");
const rest_game_service_1 = require("../services/rest.game.service");
const security_service_1 = require("../services/security.service");
let RegisterComponent = class RegisterComponent {
    constructor(fb, restAuthService, restGameService, userSecurity, router) {
        this.fb = fb;
        this.restAuthService = restAuthService;
        this.restGameService = restGameService;
        this.userSecurity = userSecurity;
        this.router = router;
        this.matchingPasswords = (passwordKey, confirmPasswordKey) => {
            return (group) => {
                let password = group.controls[passwordKey];
                let confirmPassword = group.controls[confirmPasswordKey];
                if (password.value !== confirmPassword.value) {
                    return {
                        mismatchedPasswords: true
                    };
                }
            };
        };
    }
    ngOnInit() {
        this.complexForm = this.fb.group({
            //                'name' : [null,  Validators.compose([Validators.required, Validators.minLength(2), Validators.maxLength(50)])],
            'name': [null, [forms_1.Validators.required, forms_1.Validators.minLength(2), forms_1.Validators.maxLength(50)]],
            'username': [null, forms_1.Validators.compose([forms_1.Validators.required, forms_1.Validators.minLength(2), forms_1.Validators.maxLength(20)])],
            'email': [null, forms_1.Validators.compose([forms_1.Validators.required, forms_1.Validators.pattern(/^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i)])],
            'password': [null, forms_1.Validators.required],
            'password2': [null, forms_1.Validators.required]
        }, { validator: this.matchingPasswords('password', 'password2') });
        this.resetData();
    }
    resetData() {
        this.lastRepeatedUsername = "";
        this.lastRepeatedEmail = "";
        this.complexForm.reset();
    }
    submitForm(form, event) {
        for (let i in this.complexForm.controls) {
            this.complexForm.controls[i].markAsDirty();
        }
        if (this.complexForm.invalid) {
            event.preventDefault();
        }
        else {
            this.register(form);
        }
    }
    register(form) {
        let component = this;
        this.restAuthService.checkUniqueUsername(form.username)
            .subscribe(username => {
            component.lastRepeatedUsername = '';
            component.restAuthService.checkUniqueEmail(form.email)
                .subscribe(email => {
                component.lastRepeatedEmail = "";
                component.restGameService.preregister(form.name, form.email, form.username)
                    .subscribe(userInfo => {
                    component.restAuthService.registerUser(userInfo, form.password)
                        .subscribe(token => {
                        this.userSecurity.authenticateUserFromToken(token);
                        this.router.navigateByUrl('/home');
                    }, error => {
                        console.error(error); //registerUser
                    });
                }, error => {
                    console.error(error);
                });
            }, error => {
                component.lastRepeatedEmail = form.email;
            });
        }, error => {
            component.lastRepeatedUsername = form.username;
        });
    }
};
RegisterComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'register',
        templateUrl: 'register.component.html'
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder,
        rest_auth_service_1.RestAuthService,
        rest_game_service_1.RestGameService,
        security_service_1.UserSecurityService,
        router_1.Router])
], RegisterComponent);
exports.RegisterComponent = RegisterComponent;
//# sourceMappingURL=register.component.js.map