"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const router_1 = require("@angular/router");
const forms_1 = require("@angular/forms");
const global_service_1 = require("../services/global.service");
const rest_auth_service_1 = require("../services/rest.auth.service");
const security_service_1 = require("../services/security.service");
let LoginComponent = class LoginComponent {
    constructor(fb, restAuthService, router, userSecurity, global) {
        this.fb = fb;
        this.restAuthService = restAuthService;
        this.router = router;
        this.userSecurity = userSecurity;
        this.global = global;
    }
    ngOnInit() {
        this.complexForm = this.fb.group({
            'username': [null, forms_1.Validators.compose([forms_1.Validators.required, forms_1.Validators.minLength(2), forms_1.Validators.maxLength(20)])],
            'password': [null, forms_1.Validators.required]
        });
        this.resetData();
        this.msgTitle = "";
        this.msgWarning = "";
        this.redirectTo = "/lobby";
        if (this.global.flashMsg != null) {
            this.msgTitle = this.global.flashMsg.msgTitle;
            this.msgWarning = this.global.flashMsg.msgWarning;
        }
        if (this.global.redirectTo != "") {
            this.redirectTo = this.global.redirectTo;
        }
        this.global.resetAll();
    }
    resetData() {
        this.msgValidation = "";
        this.complexForm.reset();
    }
    showWarning() {
        return this.msgTitle != "";
    }
    submitForm(form, event) {
        for (let i in this.complexForm.controls) {
            this.complexForm.controls[i].markAsDirty();
        }
        if (this.complexForm.invalid) {
            event.preventDefault();
        }
        else {
            this.login(form);
        }
    }
    login(form) {
        this.restAuthService.authenticate(form.username, form.password)
            .subscribe(token => {
            this.userSecurity.authenticateUserFromToken(token);
            this.router.navigateByUrl(this.redirectTo);
        }, error => {
            this.msgValidation = "Credentials are invalid!";
        });
    }
};
LoginComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'login',
        templateUrl: 'login.component.html'
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder,
        rest_auth_service_1.RestAuthService,
        router_1.Router,
        security_service_1.UserSecurityService,
        global_service_1.Global])
], LoginComponent);
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map